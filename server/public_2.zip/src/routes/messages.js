import express from "express";
import {
  createMessage,
  getAllMessage,
} from "../controllers/messages.js";

const router = express.Router();

//CREATE
router.post("/", createMessage);
//GET ALL
router.get("/", getAllMessage);

export default router;

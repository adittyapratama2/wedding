import Messages from "../models/Messages.js";

//CREATE MESSAGES
export const createMessage = async (req, res, next) => {
  const newMsg = new Messages(req.body);
  
  try {
      const savedMsg = await newMsg.save();
      res.status(200).json(savedMsg);
  } catch (err) {
      res.status(500).json({
      msg: err.message,
    });
  }
};


//GET ALL MSG
export const getAllMsg = async (req, res, next) => {
  try {
    const messages = await Messages.findAll();
    res.status(200).json(messages);
  } catch (err) {
    res.status(500).json({
      msg: err.message,
    });
  }
};